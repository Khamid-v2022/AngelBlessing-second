
<body>
    <section class="main hear-your-angel">
        <div class="google-ads-place">
            <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-6130278165783644" crossorigin="anonymous"></script>
            <!-- angel number top -->
            <ins class="adsbygoogle"
                 style="display:block"
                 data-ad-client="ca-pub-6130278165783644"
                 data-ad-slot="1070053482"
                 data-ad-format="auto"
                 data-full-width-responsive="true"></ins>
            <script>
                 (adsbygoogle = window.adsbygoogle || []).push({});
            </script>
        </div>
        <div class="container">
            <div class="p-4 m-4 bx-desn">
                <h3 class="magic-bx-heading">Want to know <span class="extra">what Message Your Guardian Angel</span>  has for you?</h3>
                <p class="magic-bx-sbheading">Click Button Below To Reveal Your Angel Number And Its Hidden Meaning.</p>
                <div class="wing-box">
                    <img src="<?=base_url()?>assets/img/angelhelp.gif" class="wing-img angel-number-btn">
                    <button class="send-btn mt-4 angel-number-btn">click here to receive your angel number</button>
                </div>
            </div>
        </div>
        <div class="google-ads-place">
            <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-6130278165783644" crossorigin="anonymous"></script>
            <!-- angel number bottom -->
            <ins class="adsbygoogle"
                 style="display:block"
                 data-ad-client="ca-pub-6130278165783644"
                 data-ad-slot="8565400125"
                 data-ad-format="auto"
                 data-full-width-responsive="true"></ins>
            <script>
                 (adsbygoogle = window.adsbygoogle || []).push({});
            </script>
        </div>
    </section>
</body>